__version__ = "0.1.0"

from . import trial
from . import channels
from . import read
from . import sig_proc
from . import plot
from . import types
from . import demo
